export const PATH_NEW_DRAGON_ONE = 'IMAGES/1.png';
export const PATH_NEW_DRAGON_TWO = 'IMAGES/2.png';

export const PATH_PLANE_RIGHT = 'IMAGES/plane-to-right.png';
export const PATH_RIGHT_MOVIMENT = 'IMAGES/plane-moviment-right.png';

export const PATH_PLANE_LEFT = 'IMAGES;plane-to-left.png';

export const PATH_FIRE_BALL = 'IMAGES/fire-ball.png';
export const PATH_BOMB_IMAGE = 'IMAGES/bomb.png';

export const PATH_BACKGROUND_IMAGE = 'IMAGES/background-war-bomb.png';
export const PATH_BACKGROUND2_IMAGE = 'IMAGES/background-2.jpg';
export const PATH_BACKGROUND3_IMAGE = 'IMAGES/background-3.jpg';
export const PATH_FINISH_BACKGROUND = 'IMAGES/finish-background-image.png';

export const PATH_BG_NEW1 = 'IMAGES/bg-new-1.png';
export const PATH_BG_NEW2 = 'IMAGES/bg-new-2.png';

export const PATH_ROCK_IMAGE = 'IMAGES/rock.png';

export const PATH_EXPLOSION_GIF = 'IMAGES/gif-explosion.gif';
export const PATH_FIREDRAGON_GIF = 'IMAGES/gif-fire-dragon.gif';
